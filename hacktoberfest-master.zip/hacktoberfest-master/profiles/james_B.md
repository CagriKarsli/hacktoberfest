# James Brett   

### Location

Fairhope, AL

### Academics

Covalence Bootcamp and University of Mississippi/UWF CyberSecurity

### Interests

- Web Design
- Security Software
- Machine Learning
- Javascript
- Hardware

### Projects


### Profile Link

[James Brett](https://github.com/jmsbrett)