# Amlaan Bhoi

### Academics

- UIC

### Interests

- Dogs
- Rick and Morty

### Projects

- [In Your Room](https://amlaanb.github.io/PROJECT1/) VR Application made in Unity3D


### Profile Link

[amlaanb](https://github.com/amlaanb)