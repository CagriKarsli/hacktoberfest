# Guillaume Bayle

### Location

Troyes, France

### Academics

Bachelor degree at the University of Technology of Troyes

### Interests

Information security
Computer hacking
Calisthenics

### Development

Complete beginner here, I learned the basic in Java and C, but not much else. Still a loooot to learn haha !

### Projects

Complete my degree
Master information security and general hacking (this one might take a long time)
Master the front and back lever (example [here](https://www.youtube.com/watch?v=Ev2caBjnwRo) and [here](https://www.youtube.com/watch?v=HXaG8mJmSnU&t=224s)

### Profile link
[lesyntheti](github.com/lesyntheti)
