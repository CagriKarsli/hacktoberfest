# Niall Cartwright

### Location

Birmingham, UK

### Interests

- Unity3D and Games Development
- Python 2/3
- Image Rendering and Cartographic representation
- Memes 
- /r/ProgrammerHumor
- Game of Thrones

### Development

- C++/Java/C# Application Development Software Engineer

### Projects

- [ITC#]() A C# implementation of the popular autotracker-bu python script by Greesemonkey

### Profile Link

[Alice Chuang](https://github.com/AliceWonderland)