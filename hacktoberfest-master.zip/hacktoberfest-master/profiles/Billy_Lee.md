Billy Lee 
======

### Software Developer
Powercode 2016-Current

### Education
Metropolitan State University Bachelor of Science in Computer Science
