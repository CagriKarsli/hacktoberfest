# Gagan Ganapathy

### Location

India

### Academics

Indian Institute of Information Technology Allahabad (IIIT Allahabad)

### Interests

- Counter Strike
- Movies
- Contributing to open source projects
- Speed Cubing

### Development

- Full stack developer and competitive coder.

### Projects

- [AnythingBot](https://github.com/CodHeK/AnythingBot) Chat Bot which answers to many of your queries made only using jQuery

### Profile Link

[CodHeK](https://github.com/CodHeK)
