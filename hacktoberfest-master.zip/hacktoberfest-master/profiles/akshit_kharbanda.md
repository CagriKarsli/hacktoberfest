# Akshit Kharbanda

### Location

New Delhi, India

### Academics

5th sem IT undergrad. Expected grad: June'19

### Interests

- Data Structure
- Algorithm Designing
- Machine Learning
- Computer Games
- Memes

### Projects

- Data Mining using Clustering Techniques
- Face Recognition
- Text Recognition

### Profile Link

[Akshit Kharbanda](https://github.com/akshit04)