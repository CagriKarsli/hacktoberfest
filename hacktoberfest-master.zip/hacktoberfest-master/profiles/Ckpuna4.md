# Ckpuna4

### Location

Saint-Petersburg, Russia

### Academics

Master Degree in Computer Science

### Interests

— my сolleagues
— JavaScript
— riichi mahjong
– music

### Development

- currently employed as Web Developer

### Projects

- [devSchacht](https://github.com/devSchacht) take some part in translating

### Profile Link

[Ckpuna4](https://github.com/Ckpuna4)
