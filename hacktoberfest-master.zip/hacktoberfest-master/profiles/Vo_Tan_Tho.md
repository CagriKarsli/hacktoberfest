# Vo Tan Tho

### Academics

- College at Hutech University

### Interests

- Web Development 
- Machine Learning

### Projects

- [Stock Chart](https://github.com/kensupermen/stock_chart) suggests trades when and which stocks to buy or sell(only for Vietnam)

### Profile Link

[Vo Tan Tho](https://github.com/kensupermen)
