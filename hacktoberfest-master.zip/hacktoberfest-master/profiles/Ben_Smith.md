# Ben Smith

### Location

Salt Lake City, UT, USA

### Academics

Mechanical Engineering, University of Utah

### Development

I like to write bots.

### Projects

I'm working on learning react atm.

### Profile Link

# [Check out my Github page](https://github.com/ben-w-smith)