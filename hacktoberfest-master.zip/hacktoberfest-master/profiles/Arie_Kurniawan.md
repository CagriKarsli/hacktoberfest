# Arie Kurniawan

### Location

Jakarta, Indonesia

### Academics

University of Muhammadiyah Jakarta

### Interests

- Open Source, Networking

### Development

- Website

### Projects

- [ceksipo](https://github.com/arkwrn/ceksipo) Check for Translation in .po / .mo fileription

### Profile Link

[Arie Kurniawan](https://github.com/arkwrn)
