# Caio Calderari

### Academics

- Advertising at DeVry Metrocamp

### Interests

- Web Design
- Design
- UX, UI
- Advertising
- Web Development

### Projects

- [Meetup Design Campinas](https://github.com/meetupdesigncampinas) I'm founder/organizer of a meetup group to learn and share knowledge about design in the city of Campinas, São Paulo, Brazil.)

### Profile Link

[Caio Calderari](https://github.com/caiocall)
