# Siddhant Verma

### Location

Delhi, India

### Academics

MS in Information Assurance and Cybersecurity, Northeastern University, Boston, MA

### Interests

- Web and Mobile Application Development.
- API Debugging and Testing.
- First Person Shooters.
- Hiking.

### Development

- There's nothing I can't do. You can hit me with any language, anything. I will do it. Hehe.

### Projects

- Few in Django, Android, and Spring.

### Profile Link

[Siddhant Verma](https://github.com/siddver007)