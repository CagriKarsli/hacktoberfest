# Sarthak Bhagat

### Location

Delhi, India

### Academics

Indraprastha Institute of Information Technology, Delhi 

### Interests

- Cooding
- Robotics
- Football

### Development

- Made several websites

### Projects

- [Chakravuyha Website](https://github.com/sarthak268/Chakravuyha_Website) Website for online cryptic hunt called Chakravuyha. Front-end in HTML,CSS and JS, Back-end in Flask, Database Management in SQLite and Encrypted in SHA256

### Profile Link

[Sarthak Bhagat](https://github.com/sarthak268)
