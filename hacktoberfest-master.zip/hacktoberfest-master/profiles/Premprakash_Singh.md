# PremPrakash Singh

### Location

Mumbai, India

### Academics

BE in Computer Engineering from Rajiv Gandhi Institute of Technology, Mumbai

### Interests

- Programming, Reading, Listening Music and attending tech meetups.

### Development

- Inventor of MeetupBot for Slack

### Projects

- [MeetupBot for Slack](https://github.com/MeetupBotTeam/slack-meetup-bot) -
MeetupBot is a slack bot which gives you the list of meetups going on nearby your location. It's a slack bot built using Google Geocode API and Meetup API. It allows you to search for list of meetup events/groups nearby your location based on your interest.

### Profile Link

[PremPrakash Singh](https://github.com/PREMPRAKASHSINGH)
