## Juan Pablo Aguilar-Lliguin

### Location

Chicoutimi (Qc)

### Interests

- Ecommerce
- Photography
- js
- python
- php

### Profile Link

[Juan Pablo Aguilar-Lliguin](https://github.com/chefjuanpi)
