# Michael Nyamande

### Academics

National University of Science and Technology , ZW

### Interests

- Pop , Sci-fi , Chess

### Development

- Mobile Apps
- PWA's
- Bots

### Projects

- In progress ; )

### Profile Link

[Mikeyny](https://github.com/mikeyny)
