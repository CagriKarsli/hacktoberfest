# Will Barker

### Academics

- Graduated with a B.A. in Creative Industries at Ryerson University
- Autodidact: studying programming, machine learning, and math through online resources

### Interests

- Machine Learning/Deep Learning 
- Data Analysis
- Product Development
- PYTHON PROGRAMMING!

- Calisthenics
- Volleyball
- Film
- Videogames (Smash Bros, DotA, hopefully gonna buy a switch >:D)

### Projects

- [Bukowski Bot](https://github.com/billwarker/bukowski-bot-v2) Randomly generated poetry tweets in the style of Charles Bukowski
- [Dota 2 Analysis](https://github.com/billwarker/opendota-analysis) Exploratory Data Analysis of the 3647 games of Dota 2 I played from 2012-2017

### Profile Link

[Will Barker](https://github.com/billwarker)