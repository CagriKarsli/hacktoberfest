# Jesse Lyon

### Location

Melbourne, Australia

### Academics

Point Cook P-9 College

### Interests

- Programming
- Computer Science
- Cooking
- Sport
- Movies

### Development

- I just write mobile apps for fun!

### Projects

- [Movie Database](https://github.com/DamianLazarR/MovieDatabase) A searchable movie database.

### Profile Link

[ProfessorNudelz](https://github.com/ProfessorNudelz)