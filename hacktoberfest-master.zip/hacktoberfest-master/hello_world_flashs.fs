// LANGUAGE: FSharp
// ENV: .NET Core
// AUTHOR: Felix 
// GITHUB: https://github.com/Flashs
// More on FSharp: https://fsharpforfunandprofit.com/
open System

[<EntryPoint>]
let main argv = 
    printfn "Hello World" 
    0
