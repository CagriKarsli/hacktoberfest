﻿#### Name: [ALICE CHUANG](https://github.com/AliceWonderland)
- Place: New York City, NY, USA
- Bio: I love DOGS! :dog:
- GitHub: [Alice Chuang](https://github.com/AliceWonderland)

#### Name: [GABE DUNN](https://github.com/redxtech)
- Place: Canada
- Bio: I love VUE !!
- GitHub: [Gabe Dunn](https://github.com/redxtech)
- Website: [when.](https://when.redxte.ch)

#### Name: [GEORGE FOTOPOULOS](https://github.com/xorz57)
- Place: Patras, Achaia, Greece
- Bio: Technology Enthusiast
- GitHub: [George Fotopoulos](https://github.com/xorz57)

#### Name: [Stephen Dzialo](https://github.com/dzials)
- Place: USA
- Bio: Computer Science Major
- GitHub: [Stephen Dzialo](https://github.com/dzials)

#### Name: [Taf Meister](https://github.com/tashrafy)
- Place: NYC
- Bio: Developer =]

#### Name: [RAFAEL MENEZES](https://github.com/RafaelSa94)
- Place: Boa Vista, Roraima, Brazil
- Bio: Computer Science Major
- GitHub: [Rafael Sá](https://github.com/RafaelSa94)

#### Name: [Patrick S](https://github.com/patsteph)
- Place: USA
- Bio: Professional Geek
- GitHub: [Patrick S](https://github.com/patsteph)

#### Name: [Michael Cao](https://github.com/mcao)
- Place: PA, USA
- Bio: Student
- GitHub: [Michael Cao](https://github.com/mcao)

#### Name: [Amlaan Bhoi](https://github.com/amlaanb)
- Place: IL, USA
- Bio: CS Grad Student
- GitHub: [Amlaan Bhoi](https://github.com/amlaanb)

#### Name: [Cecy Correa](https://github.com/cecyc)
- Place: USA
- Bio: Software Engineer at ReturnPath
- Github: [cecyc](https://github.com/cecyc)

#### Name: [Billy Lee](https://github.com/leebilly0)
- Place: WI, USA
- Bio: Software Developer, Bachelors in Computer Science
- Github: [Billy Lee](https://github.com/leebilly0)

#### Name: [AGNIESZKA MISZKURKA](https://github.com/agnieszka-miszkurka)
- Place: Poland
- Bio: second year Computer Science Student, in love with NYC <3
- GitHub: [agnieszka-miszkurka](https://github.com/agnieszka-miszkurka)

#### Name: [Leah Langfrod](https://github.com/leahlang4d2)
- Place: CA, USA
- Bio: Recent Bachelors in Computer Science
- Github: [Leah Langford](https://github.com/leahlang4d2)

#### Name: [Eric Nor](https://github.com/thateric)
- Place: Lake Forest, CA, USA
- Bio: Multiple corgi owner and a Senior Software Developer
- Github: [Eric Nord](https://github.com/thateric)

#### Name: [Campion Fellin](https://github.com/campionfellin)
- Place: Seattle, WA, USA
- Bio: I love open source and coffee! New grad looking for work!
- GitHub: [Campion Fellin](https://github.com/campionfellin)

#### Name: [Niket Mishra](https://github.com/niketmishra)
- Place: New Delhi, Delhi, India
- Bio: B.Tech Student in Information Technology
- GitHub: [Niket Mishra](https://github.com/niketmishra)

#### Name: [Shade Ruangwan](https://github.com/sruangwan)
- Place: Nara, Japan
- Bio: PhD student in Software Engineering
- Github: [Shade Ruangwan](https://github.com/sruangwan)

#### Name: [Michael Rodriguez](https://github.com/vinird)
- Place: Alajuea, Alajuela, Costa Rica
- Bio: Web dev adn graphic designer
- GitHub: [vinird](https://github.com/vinird)

#### Name: [Evan Culver](https://github.com/eculver)
- Place: San Francisco, CA, USA
- Bio: I work at Uber on data storage, tooling and OOS - checkout [our work](https://github.com/uber-go/dosa)!
- GitHub: [Evan Culver](https://github.com/eculver)

#### Name: [Vo Tan Tho](https://github.com/kensupermen)
- Place: Ho Chi Minh City, VietNam
- Bio: I'm Software Engineer at Dinosys
- GitHub: [Ken Supermen](https://github.com/kensupermen)

#### Name: [Franklyn Roth](https://github.com/far3)
- Place: Boulder, CO, USA
- Bio: I am a web developer working on finance sites. Specialize in accessibility.
- GitHub: [Franklyn Roth](https://github.com/far3)

#### Name: [Karthick Thoppe](https://github.com/karthicktv)
- Place: Dublin, Ireland
- Bio: I am a Solution Architect and work for a large SaaS organization
- GitHub: [Karthick Thoppe](https://github.com/karthicktv)

#### Name: [Brane](https://github.com/brane)
- Place: Turkey
- Bio: I am a caffeine based artificial life form.
- GitHub: [Brane](https://github.com/brane)

#### Name: [Ishan Jain](https://github.com/ishanjain28)
- Place: Roorkee, Uttrakhand, India
- Bio: I love working with Images, Crypto, Networking and opengl, Work as a Backend Engineer in Go. Also, Love Rust!.
- Github: [Ishan Jain](https://github.com/ishanjain28)

#### Name: [Anupam Dagar](https://github.com/Anupam-dagar)
- Place: Allahabad, India
- Bio: I am like a code currently in development.
- GitHub: [Anupam Dagar](https://github.com/Anupam-dagar)

#### Name: [Phil](https://github.com/bitbrain-za)
- Place: South Africa
- Bio: Avid Tinkerer
- GitHub: [bitbrain-za](https://github.com/bitbrain-za)

#### Name: [Jasdy Syarman](https://github.com/akutaktau)
- Place: Malaysia
- Bio: PHP Programmer
- GitHub: [akutaktau](https://github.com/akutaktau)

#### Name: [Rupesh Kumar](https://github.com/vmcniket)
- Place: India
- Bio: KIIT University IT student
- GitHub: [vmcniket](https://github.com/vmcniket)

#### Name: [Shelby Stanton](https://github.com/Minimilk93)
- Place: Leeds, England
- Bio: Front End Developer who loves cats and gaming!
- GitHub: [Minimilk93](https://github.com/Minimilk93)

#### Name: [Michael Nyamande](https://github.com/mikeyny)
- Place: Harare ,Zimbabwe
- Bio: Eat , ~~Sleep~~ , Code
- GitHub: [Mikeyny](https://github.com/mikeyny)

#### Name: [Anders Jürisoo](https://github.com/ajthinking)
- Place: Sweden
- Bio: What happens in Git stays in Git
- GitHub: [Anders Jürisoo](https://github.com/ajthinking)

#### Name: [Dvir](https://github.com/dvur12)
- Place: Israel
- Bio: \x90\x90\x90\x90
- GitHub: [Dvir](https://github.com/dvur12)

#### Name: [Xavier Marques](https://github.com/wolframtheta)
- Place: Corbera de Llobregat, Barcelona, Catalonia
- Bio: Computer Science Major
- GitHub: [WolframTheta](https://github.com/wolframtheta)

#### Name: [Vishal](https://dainvinc.github.io)
- Place: New York
- Bio: Software developer with a knack to learn things quickly.
- GitHub: [dainvinc](https://github.com/dainvinc)

### Name: [Niall Cartwright](https://github.com/Nairu)
- Place: Birmingham, UK
- Bio: Avid Games dev hobbyist, work for 3SDL as a software developer.
- GitHub: [Niall Cartwright](https://github.com/Nairu)

#### Name: [Justin I](https://github.com/Jish80)
- Place: IL, USA
- Bio: Work hard
- GitHub: [Jish80] (https://github.com/Jish80)

#### Name: [APOORVA SHARMA](https://github.com/okatticus)
- Place: Himachal Pradesh,India
- Bio: A student happy to write code and poetry.
- GitHub: [Apoorva Sharma](https://github.com/okatticus)

#### Name: [Prateek Pandey](https://github.com/prateekpandey14)
- Place: Bangalore, India
- Bio: Opensource Enthusiast, Opensource Golang developer
- GitHub: [Prateek Pandey](https://github.com/prateekpandey14)

#### Name: [CodHeK](https://github.com/CodHeK)
- Place: Mumbai, India
- Bio: Cuber/Coder
- GitHub: [CodHeK](https://github.com/CodHeK)

#### Name: [Søren Eriksen](https://github.com/soer7022)
- Place: Denmark
- Bio: Currently studying computerscience at Aarhus University
- Github: [Søren Eriksen](https://github.com/soer7022)

#### Name: [Cristiano Bianchi](https://github.com/crisbnk)
- Place: Italy
- Bio: Love to learn something new everyday
- GitHub: [crisbnk](https://github.com/crisbnk)


#### Name: [Paulo Henrique Scherer](https://github.com/phscherer)
- Place: Brazil
- Bio: Student and newbie software developer
- GitHub: [phscherer](https://github.com/phscherer)

#### Name: [Aldo Cano](https://github.com/aldocano)
- Place: Tirana, Albania
- Bio: A bug is never just a mistake...
- GitHub: [Aldo Cano](https://github.com/aldocano)

#### Name: [Timea Deák](https://github.com/DTimi)
- Place: Dublin, Ireland
- Bio: Molecular biologist
- GitHub: [Timea Deák](https://github.com/DTimi)

#### Name: [Christian Skala](https://github.com/chrishiggins29)
- Place: New York, USA
- Bio: Hire me! Need a VP of Engineering, Director of Software, CTO?
- GitHub: [Christian Skala](https://github.com/chrishiggins29)

#### Name: [filedesless](https://hightechlowlife.info)
- Place: Québec, Canada
- Bio: CompSci from ULaval reporting in
- GitHub: [aiglebleu](https://github.com/aiglebleu)

#### Name: [Jon Lee](https://github.com/githubbbbbbbbbbbbb)
- Place: Canada
- Bio: Student
- GitHub: [githubbbbbbbbbbbbb](https://github.com/githubbbbbbbbbbbbb)

#### Name: [Ren Cummings](https://github.com/nrenc027)
- Place: Dayton,OH, USA
- Bio: I like Code :sunglasses:, Coloring :art:, and Cardio :running:
- GitHub: [Ren Cummings](https://github.com/nrenc027)

#### Name: [Nefari0uss](https://github.com/nefari0uss)
- Place: USA
- Bio: Gamer, developer, and open source enthusiast!
- Github: [Nefari0uss](https://github.com/nefari0uss)

#### Name: [S Stewart](https://github.com/tilda)
- Place: Denton, Texas, US
- Bio: Dude trying to become a IT guy somewhere. Also reads [The Register](https://www.theregister.co.uk).
- GitHub: [tilda](https://github.com/tilda)

#### Name: [Jose Gomera](https://github.com/josegomera)
- Place: Dominican Republic
- Bio: I'm web developer that love somehow to help.
- Github: [josegomera](https://github.com/josegomera)

#### Name: [Stephen Abrahim](https://github.com/lepah)
- Place: Huntington Beach, CA
- Bio: Games and things!
- GitHub: [Stephen Abrahim](https://github.com/lepah)

#### Name: [Rajeev Kumar Singh](https://github.com/rajeeviiit)
- Place: Gandhinagar,Gujrat, IN
- Bio: Games and music!
- GitHub: [Rajeev Kumar Singh](https://github.com/rajeeviiit)

### Name: [Benjamin Sanvoisin](https://github.com/Laudenlaruto)
- Place : Paris, FR
- Bio: Devops, Gamer and fun
- GitHub: [Benjamin Sanvoisin](https://github.com/Laudenlaruto)

#### Name: [Matthew Burke](https://github.com/MatthewBurke1995)
- Place: Sydney, Australia
- Bio: Big fan of Python + Data
- GitHub: [Matthew Burke](https://github.com/MatthewBurke1995)

#### Name: [Caio Perdona](https://github.com/perdona)
- Place: Ribeirao Preto, SP, Brazil
- Bio: Web and Mobile Engineer
- GitHub: [Caio Perdona](https://github.com/perdona)

#### Name: [Shankhalika Sarkar](https://github.com/Shankhalika)
- Place: Karnataka, India
- Bio: Current Final Year CS Undergrad. I love poetry, tea and dogs.
- Github: [Shankhalika Sarkar](https://github.com/Shankhalika)

#### Name: [Henrique Duarte](https://github.com/mustorze)
- Place: São Paulo, SP, BR
- Bio: Developer, I really like!
- GitHub: [Henrique Duarte](https://github.com/mustorze)

#### Name: [Akshit Kharbanda](https://github.com/akshit04)
- Place: Delhi, India
- Bio: 5th semester IT Undergrad. Machine Learning enthusiast. Black coffee <3
- GitHub: [Akshit Kharbanda](https://github.com/akshit04)

#### Name:[Avinash Jaiswal](https://github.com/littlestar642)
- Place:Surat,Gujarat,India.
- Bio:In love with the WEB,from age of 5!
- Github:[Avinash Jaiswal](https://github.com/littlestar642)

#### Name: [JoeBanks13](https://github.com/JoeBanks13)
- Place: York, United Kingdom
- Bio: Backend web developer
- GitHub: [JoeBanks13](https://github.com/JoeBanks13)
- Webpage: [josephbanks.me](https://josephbanks.me)
- GitLab Server: [GitLab](https://gitlab.josephbanks.me/JoeBanks13)

#### Name: [Alisson Vargas](https://github.com/alisson-mich)
- Place: Torres, RS, Brazil
- Bio: A guy who loves IT :D
- GitHub: [Alisson Vargas](https://github.com/alisson-mich)

#### Name: [Mat.](https://github.com/pudkipz)
- Place: Stockholm, Sweden
- Bio: Random Swedish student.
- GitHub: [Mat.](https://github.com/pudkipz)

#### Name: [Adiyat Mubarak](https://github.com/Keda87)
- Place: Jakarta, ID, Indonesia
- Bio: Technology Agnostic
- GitHub: [Adiyat Mubarak](https://github.com/Keda87)

#### Name: [Vishaal Udandarao](https://github.com/vishaal27)
- Place: New Delhi, India
- Bio: Professional Geek | Developer
- GitHub: [Vishaal Udandarao](https://github.com/vishaal27)

#### Name: [Sparsh Garg](https://github.com/sparsh789)
- Place: Hyderabad, Telangana, India
- Bio: Student@IIIT,Hyderabad
- GitHub: [sparsh789](https://github.com/sparsh789)

#### Name: [Zaki Akhmad](https://github.com/za)
- Place: Jakarta, Indonesia
- Bio: Python enthusiasts
- GitHub: [za](https://github.com/za)

### Name: [Joey Marshment-Howell](https://github.com/josephkmh)
- Place: Berlin, Germany
- Bio: A nice young man who likes web programming!
- GitHub: [Joey Marshment-Howell](https://github.com/josephkmh)

#### Name: [Chris Sullivan](https://github.com/codemastermd)
- Place: College Park, Maryland
- Bio: Comp Sci student at the University of Maryland
- GitHub: [Chris Sullivan](https://github.com/codemastermd)

### Name: [Owen Mitchell](https://github.com/ultimatezenzar)
- Place: Edmond, OK, United States
- Bio: Programmer for a high school robotics team
- Github: [ultimatezenzar] (https://github.com/ultimatezenzar)

#### Name: [Sravya Pullagura](https://github.com/sravya96)
- Place: Vijayawada, Andhra Pradesh, India
- Bio: Love learning, coding and sketching!!
- Github [Sravya Pullagura](https://github.com/sravya96)

#### Name: [Ahmad Musaddiq Mohammad](https://github.com/ahmadmusaddiq)
- Place: Kuala Belait, Brunei Darussalam
- Bio: Mechanical engineer
- Github: [ahmadmusaddiq](https://github.com/ahmadmusaddiq)

#### Name: [Rafael Lima](https://github.com/rafaelkalan)
- Place: Belo Horizonte, Minas Gerais, Brazil
- Bio: Youger software engineer
- GitHub: [Rafael Lima](https://github.com/rafaelkalan)

#### Name: [Saif Rehman Nasir](https://github.com/shyshin)
- Place: New Delhi, India
- Bio: Techie with a lot of horizontals but a low verticality :(
- Github: [Saif Rehman Nasir](https://github.com/shyshin)

#### Name: [Yash Mittra](https://github.com/mittrayash)
- Place: New Delhi, Delhi, India
- Bio: Web Developer, Coder | Entering the field of Machine Learning and Data Science
- GitHub: [mittrayash](https://github.com/mittrayash)

#### Name: [Dustin Woods](https://github.com/dustinywoods)
- Place: MN, USA
- Bio: Software Developer
- GitHub: [Dustin Woods](https://github.com/dustinywoods)

#### Name: [Ginanjar S.B](https://github.com/egin10)
- Place: Samarinda, Kalimantan Timur, Indonesia
- Bio: Someone who's intresting about web devlopment / Programming
- GitHub: [Ginanjar S.B | egin10](https://github.com/egin10)

#### Name: [Fush Chups](https://github.com/fushandchups)
- Place: Christchurch, Canterbury, New Zealand
- Bio: Earhquake enthusiast
- GitHub:[fushandchups] (https://github.com/fushandchups)

#### Name: [Francis Venne](https://github.com/NullSilence)
- Place: Montreal, Canada.
- Bio: Developer by day, cat lover by night. Canadian tech enthusiast.
- Github [Sravya Pullagura](https://github.com/NullSilence)

#### Name: [Leonardo Bonetti](https://github.com/LeonardoBonetti)
- Place: São Paulo, Brazil
- Bio: Associate Degree analysis and systems development
- GitHub: [Leonardo Bonetti](https://github.com/LeonardoBonetti)

#### Name: [Noveen Sachdeva](https://github.com/noveens)
- Place: Hyderabad, Telangana, India
- Bio: 3rd Year CS undergrad at IIIT Hyderabad.
- GitHub: [Noveen Sachdeva](https://github.com/noveens)

#### Name: [DENNIS ORZIKH](https://github.com/orzikhd)
- Place: Seattle, WA, USA
- Bio: Student at UW. Likes easy ways to make sure tools are set up in new environments (like this project)
- Github: Wow isn't this right up there ^ [Dennis Orzikh](https://github.com/orzikhd)

#### Name: [Pranav Bhasin](https://github.com/pranavbhasin96)
- Place: Hyderabad, Telangana, India
- Bio: Trying to fit in coding society.
- GitHub: [Pranav Bhasin](https://github.com/pranavbhasin96)

#### Name: [Vaibhav Agarwal](https://github.com/vaibhavagarwal220)
- Place: Mandi, Himachal Pradesh, India
- Bio: A passionate programmer and a beginner in Open Source
- Github [Vaibhav Agarwal](https://github.com/vaibhavagarwal220)

#### Name: [Arpit Gogia](https://github.com/arpitgogia)
- Place: Delhi, India
- Bio: Python Developer
- Github [Arpit Gogia](https://github.com/arpitgogia)

#### Name: [Charlie Stanton](https://github.com/shtanton)
- Place: Southend-On-Sea, England
- Bio: JavaScript Tinkerer, Lover of Vim
- Github [Charlie Stanton](https://github.com/shtanton)

#### Name: [James Henderson](https://github.com/prohunt)
- Place: Raleigh, NC, United States
- Bio: Inquisitive, Loves coding, also vegan
- Github [Sravya Pullagura](https://github.com/sravya96)

#### Name: [Loreleen Mae Sablot](https://github.com/loreleensablot)
- Place: Daet, Camarines Norte, Philippines
- Bio: I love designing beautiful websites. I also bike.
- Github [Loreleen Mae Sablot] (https://github.com/loreleensablot)

#### Name: [Ahmad Musaddiq Mohammad](https://github.com/ahmadmusaddiq)
- Place: Kuala Belait, Brunei Darussalam
- Bio: Mechanical engineer
- Github: [ahmadmusaddiq](https://github.com/ahmadmusaddiq)

#### Name: [Aleksandr Vorontsov](https://github.com/a-vorontsov)
- Place: London, England
- Bio: Student, Aspiring Front-end Web Dev
- Github [Aleksandr Vorontsov](https://github.com/a-vorontsov)
#### Name: [Ben Smith](https://github.com/ben-w-smith)
- Place: Salt Lake City, UT, USA
- Bio: A guy that loves writing bots and automation.
- GitHub: [Ben Smith](https://github.com/ben-w-smith)

#### Name: [Eric Bryant](https://github.com/shmickle)
- Place: Fairfax, Virginia, USA
- Bio: Web Developer
- GitHub: [shmickle](https://github.com/shmickle)

#### Name: [Emmanuel Akinde](https://github.com/harkindey)
- Place: Lagos, Nigeria
- Bio: Lets Code and Chill
- Github: [Harkindey](https://github.com/harkindey)

#### Name: [Ashish Krishan](https://github.com/ashishkrishan1995)
- Place: India
- Bio: Computer Science Major / UI/UX Designer
- GitHub: [ashishkrishan1995](https://github.com/ashishkrishan1995)

#### Name: [Katherine S](https://github.com/kms6bn)
- Place: San Francisco
- Bio: Data Scientist
- Github: [kms6bn](https://github.com/kms6bn)

#### Name: [BrunoSXS](https://github.com/brunosxs)
- Brazil
- Bio: I like turtules.
- Github [BrunoSXS](https://github.com/brunosxs)

#### Name: [Alexander Miller](https://github.com/allesmi)
- Place: Salzburg, Austria
- Bio: Student/Web Developer
- GitHub: [allesmi](https://github.com/allesmi)

#### Name: [Bryan Wigianto](https://github.com/bwigianto)
- Place: USA
- Bio: Engineer
- GitHub: [bwigianto](https://github.com/bwigianto)

#### Name: [Ckpuna4](https://github.com/Ckpuna4)
- Place: Saint-petersburg, Russia
- Bio: Web Developer
- GitHub: [Ckpuna4](https://github.com/Ckpuna4)

#### Name: [Vaibhaw Agrawal](https://github.com/vaibhaw2731)
- Place: New Delhi, India
- Bio: I am a Machine Learning enthusiast.
- GitHub: [vaibhaw2731](https://github.com/vaibhaw2731)

#### Name: [Dhevi Rajendran](https://github.com/dhevi)
- Place: USA
- Bio: Software Engineer
- Github: [dhevi](https://github.com/dhevi)

#### Name: [Oluwadamilola Babalola](https://github.com/thedammyking)
- Place: Lagos, Nigeria
- Bio: JavaScript Developer
- GitHub: [Oluwadamilola Babalola](https://github.com/thedammyking)

### Name: [Trevor Meadows](https://github.com/tlm04070)
- Place: Charlotte, North Carolina.
- Bio: UNC Charlotte coding bootcamp student.
- GitHub: [tlm04070](https://github.com/tlm04070);

#### Name: [Ratchapol Tengrumpong](https://github.com/lullabies)
- Place: Bangkok, Thailand
- Bio: Programmer Analyst
- GitHub: [lullabies](https://github.com/lullabies)

#### Name: [Luke Taylor](https://github.com/lmcjt37)
- Place: Derby, UK
- Bio: Senior Software Engineer, child at heart
- GitHub: [Luke Taylor](https://github.com/lmcjt37)

#### Name: [Snehil Verma](https://github.com/vsnehil92)
- Place: Delhi, India
- Bio: Love to learn new technologies
- GitHub: [vsnehil92](https://github.com/vsnehil9

#### Name: [Akram Rameez](https://github.com/akram-rameez)
- Place: Bengaluru, India
- Bio: I like free T-shirts and I cannot lie.
- GitHub: [allesmi](https://github.com/akram-rameez)

#### Name: [Bryan Tylor](https://github.com/bryantylor)
- Place: Cincinnati, OH, USA
- Bio: Elixir Dev / Nuclear Engineer
- GitHub: [Bryan Tylor](https://github.com/bryantylor)

#### Name: [Matthias Kraus](https://github.com/brotkiste)
- Place: Munich, Germany
- Bio: Automotive Computer Science
- GitHub: [brotkiste](https://github.com/brotkiste)

#### Name: [Harshil Agrawal](https://github.com/harshil1712)
-Place: Vadodara, India
-Bio: Student,Web Developer
-GitHub: [harshil1712](https://github.com/harshil1712)

#### Name: [Bennett Treptow](https://github.com/bennett-treptow)
- Place: Milwaukee, WI, USA
- Bio: Computer Science Major / Web Developer
- Github: [bennett-treptow](https://github.com/bennett-treptow)

#### Name: [Cameron Smith](https://github.com/cameronzsmith)
- Place: Wichita, KS, USA
- Bio: Student
- GitHub: [cameronzsmith](https://github.com/cameronzsmith)

#### Name: [Jose Morales](https://github.com/castro732)
- Place: Buenos Aires, Argentina
- Bio: Developer
- GitHub: [castro732](https://github.com/castro732)

#### Name: [Hassan Sani](https://github.com/inidaname)
- Place: Bida, Niger State, Nigeria
- Bio: Web Developer at @ADPNigeria

#### Name: [Philip Terzic](https://github.com/PhilTerz)
- Place: Scottsdale, Arizona, USA
- Bio: Aspiring OSS Contributer
- GitHub: [PhilTerz](https://github.com/PhilTerz)

#### Name: [Gustavo Pacheco Ziaugra](https://github.com/GustavoZiaugra)
- Place: São Paulo, Brazil.
- Bio: Technology Guy / Student
- GitHub: [Gustavo Ziaugra](https://github.com/GustavoZiaugra)

#### Name: [Sarah Chen](https://github.com/sarovisk)
- Place: Sao Paulo/ Brazil
- Bio: Student
- GitHub: [sarovisk](https://github.com/sarovisk)

#### Name: [Jose David](https://github.com/jose4125)
- Place: Bogotá, Colombia
- Bio: Web Developer
- GitHub: [jose4125](https://github.com/jose4125)

#### Name: [Mayank Saxena](https://github.com/mayank26saxena)
- Place: New Delhi, India
- Bio: Student
- GitHub: [mayank26saxena](https://github.com/mayank26saxena)

#### Name: [Napat Rattanawaraha](https://github.com/peam1234)
- Place: Bangkok, Thailand
- Bio: Student / Junior Web Developer
- GitHub: [peam1234](https://github.com/peam1234)

#### Name: [Marion Fioen](https://github.com/marion59000)
- Place: Lille, France
- Bio: Developer
- GitHub: [marion59000](https://github.com/marion59000)

#### Name: [Akma Adhwa](https://github.com/akmadhwa)
- Place: Malaysia
- Bio: Web Developer
- GitHub: [akmadhwa](https://github.com/akmadhwa)

#### Name: [Ian James](https://inj.ms)
- Place: London, UK
- Bio: Web... person?
- GitHub: [injms](https://github.com/injms)

#### Name: [K Foster](https://foster.im)
- Place: West Sussex, UK
- Bio: Web Developer
- GitHub: [g33kcentric](https://github.com/g33kcentric)

#### Name: [Andin FOKUNANG](https://github.com/switchgirl95)
- Place: Yaounde , Cameroon
- Bio: Student - Otaku - Geek
- GitHub: [Switch](https://github.com/switchgirl95)

#### Name: [xenocideiwki] (https://github.com/xenocidewiki)
- Place: Norway
- Bio: Reverse Engineer
- GitHub: [xenocidewiki] (https://github.com/xenocidewiki)

#### Name: [George Hundmann](https://github.com/georgegsd)
- Place: Mannheim, Baden-Württemberg, Germany
- Bio: I'm a German Shepherd that likes eating
- GitHub: [georgegsd](https://github.com/georgegsd)

#### Name: [Ahmad Abdul-Aziz](https://github.com/a-m-a-z)
- Place: Abuja, Nigeria
- Bio: Web Developer
- GitHub: [a-m-a-z](https://github.com/a-m-a-z)

#### Name: [Allan Dorr](https://github.com/aldorr)
- Place: Hamburg, Germany
- Bio: Web Dev, Writer, Translator, Teacher
- GitHub: [aldorr](https://github.com/aldorr)

#### Name: [Musa Barighzaai](https://github.com/mbarighzaai)
- Place: Toronto, Canada
- Bio: Front End Developer
- GitHub: [mbarighzaai](https://github.com/mbarighzaai)

#### Name: [Lakston](https://github.com/Lakston)
- Place: Toulouse, France
- Bio: Front-End Dev
- GitHub: [Lakston](https://github.com/Lakston)

#### Name: [Shobhit Agarwal](https://github.com/shobhit1997)
- Place: JSSATE, NOIDA ,INDIA
- Bio: Student/Andriod Developer
- GitHub: [shobhit1997](https://github.com/shobhit1997)

#### Name: [Will Barker](https://github.com/billwarker)
- Place: Toronto, Canada
- Bio: A guy who wants to improve the world through AI!
- GitHub: [Will Barker](https://github.com/billwarker)

#### Name: [Christopher Bradshaw](https://github.com/kitsune7)
- Place: Provo, UT, USA
- Bio: I love FOXES!!! :fox:
- GitHub: [kitsune7](https://github.com/kitsune7)

#### Name: [Ben Edelson]
-Place: Newark NJ
-Bio: I.T.
-GitHub: https://github.com/Bed3150n

#### Name: [JOE SCHO](https://github.com/JoeScho)
- Place: London, UK
- Bio: I love guitar!
- GitHub: [JoeScho](https://github.com/JoeScho)

#### Name: [Anuraag Tummanapally](https://github.com/TummanapallyAnuraag)
- Place: Mumbai, India
- Bio: Student, System Administrator
- GitHub: [TummanapallyAnuraag](https://github.com/TummanapallyAnuraag)

#### Name: [Fran Acién](https://github.com/acien101)
- Place: Madrid, Spain
- Bio: Full of empty
- GitHub: [Fran Acién](https://github.com/acien101)

#### Name: [Piyush Sikarwal](https://github.com/psikarwal)
- Place: India
- Bio: Professional Geek
- GitHub: [Piyush Sikarwal](https://github.com/psikarwal)

#### Name: [Pratyum Jagannath](https://github.com/Pratyum)
- Place: Singapore
- Bio: I tell tales!
- GitHub: [Pratyum](https://github.com/Pratyum)

#### Name: [Jakub Bačo](https://github.com/vysocina)
- Place: Slovakia
- Bio: Student / Designer
- GitHub: [Jakub Bačo](https://github.com/vysocina)

#### Name: [Gabriel Obaldia](https://github.com/gobaldia)
- Place: Uruguay
- Bio: Full Stack Developer
- GitHub: [Gabriel Obaldia](https://github.com/gobaldia)

#### Name: [Antonio Jesus Pelaez](https://github.com/ajpelaez)
- Place: Granada, Spain
- Bio: IT Student at the University of Granada
- GitHub: [Antonio Jesus Pelaez](https://github.com/ajpelaez)

#### Name: [Mahdi Majidzadeh](https://github.com/MahdiMajidzadeh/)
- Place: Qom, Qom, Iran
- Bio: back-end develoer and seo expert
- GitHub: [Mahdi Majidzadeh](https://github.com/MahdiMajidzadeh/)
- Twitter: [Mahdi Majidzadeh](https://twitter.com/MahdiMajidzadeh/)

#### Name: [Pedro Mietto Bruini](https://github.com/bruini)
- Place: Jundiaí, São Paulo, Brazil
- Bio: Analyst/Developer Student at Fatec-Jd
- GitHub: [Pedro Mietto Bruini](https://github.com/bruini)

#### Name: [NIKOLETT HEGEDÜS](https://github.com/henikolett)
- Place: Debrecen, Hungary
- Bio: I'm a Developer / Music geek / Nature enthusiast
- GitHub: [Nikolett Hegedüs](https://github.com/henikolett)

#### Name: [Omar Mujahid](https://github.com/omarmjhd)
- Place: Austin, Texas, USA
- Bio: I write code, and play golf!
- GitHub: [Omar Mujahid](https://github.com/omarmjhd)

#### Name: [Kyle Johnson] (https://github.com/johnson90512)
- Place: United States
- Bio: Information System Administrator, former Information Systems student
- GitHub: [Kyle Johnson] (https://github.com/johnson90512)
#### Name: [Gilliano Menezes](https://github.com/gillianomenezes)
- Place: Recife, Brazil
- Bio: Software Engineer at www.neuroup.com.br
- GitHub: [Gilliano Menezes](https://github.com/gillianomenezes)

#### Name: [Luís Antonio Prado Lança](https://github.com/luisslanca)
- Place: Jundiaí, São Paulo, Brazil
- Bio: I'm a student in Fatec Jundiaí and Web Developer.
- GitHub: [Luís Antonio Prado Lança](https://github.com/luisslanca)

#### Name: [Anish Bhardwaj](https://github.com/bhardwajanish)
- Place: New Delhi, India
- Bio: CSD IIITD
- GitHub: [Anish Bhardwaj](https://github.com/bhardwajanish)

#### Name: [Ankur Sharma](https://github.com/ankurs287)
- Place: New Delhi, India
- Bio: CSAM, IIITD
- GitHub: [Ankur Sharma](https://github.com/ankurs287)

#### Name: [Siddhant Verma](https://github.com/siddver007)
- Place: Delhi, India
- Bio: Information Assurance and Cybersecurity Master's Student at Northeastern University
- GitHub: [Siddhant Verma](https://github.com/siddver007)

#### Name: [Cody Williams](https://github.com/codyw9524)
- Place: Dallas, Texas, USA
- Bio: Web Nerd
- GitHub: [Cody Williams](https://github.com/codyw9524)

#### Name: [Aayush Sharma](https://github.com/aayusharma)
- Place: Mandi, Himachal Pradesh, India
- Bio: IITian
- GitHub: [Aayush Sharma](https://github.com/aayusharma)

#### Name: [Jonas Fabisiak](https://github.com/RenCloud)
- Place: Hanover, Germany
- Bio: IT Student
- GitHub: [Jonas Fabisiak](https://github.com/RenCloud)

#### Name: [Mark Schultz](https://github.com/zynk)
- Place: Calgary, Alberta
- Bio: IT Student at SAIT
- GitHub: [Mark Schultz](https://github.com/zynk)

#### Name: [Juan Pablo Aguilar Lliguin](https://github.com/chefjuanpi)
- Place: Chicoutimi, QC, Canada
- Bio: Full Stack Developer
- GitHub: [Juan Pablo Aguilar Lliguin](https://github.com/chefjuanpi)

### Name: [Isaac Torres Michel](https://github.com/isaactorresmichel)
- Place: León, Mexico
- Bio: Software Engineer
- GitHub: [Isaac Torres Michel](https://github.com/isaactorresmichel)

#### Name: [Klaudia K.](https://github.com/KalpiKK)
- Place: Poland
- Bio: IT Student at the University of Wroclaw
- GitHub: [Klaudia K.](https://github.com/KalpiKK)

#### Name: [Luiz Gustavo Mattos](https://github.com/mano0012)
- Place: Brasil
- Bio: Computer Science Student
- Github: [Luiz Matos](https://github.com/mano0012)

#### Name: [Jeppe Ernst](https://github.com/Ern-st)
- Place: 🇩🇰
- Bio: fullstack/devops/security unicorn 🦄
- GitHub: [Jeppe Ernst](https://github.com/Ern-st)

#### Name: [Sergey Gorky](https://github.com/sergeygorky)
- Place: Ukraine
- Bio: I've Top Rated status in Upwork
- GitHub: [Sergey Gorky](https://github.com/sergeygorky)

#### Name: [Ayush Agarwal](https://github.com/thisisayaush)
- Place: Noida, India
- Bio: CSE Student at the Amity University
- GitHub: [Ayush Agarwal](https://github.com/thisisayush)

#### Name: [Arie Kurniawan](https://github.com/arkwrn)
- Place: Jakarta, Indonesia
- Bio: IT Student at Universiy of Muhammadiyah Jakarta
- GitHub: [Arie Kurniawan](https://github.com/arkwrn)

#### Name: [Ramón Didier Valdez Yocupicio](https://github.com/xDidier901)
- Place: Hermosillo, Sonora, México
- Bio: Software Developer / Student
- GitHub: [Didier Valdez](https://github.com/xDidier901)

#### Name: [Jamie Pinheiro](https://github.com/jamiepinheiro)
- Place: Canada
- Bio: Student @ uWaterloo
- GitHub: [jamiepinheiro](https://github.com/jamiepinheiro)

#### Name: [Alvin Abia](https://github.com/twist295)
- Place: NY, USA
- Bio: Lead Mobile Developer
- Github: [Alvin Abia](https://github.com/twist295)

### Name: [Carlos Federico Lahrssen](https://github.com/carloslahrssen)
- Place: Miami, Florida, USA
- Bio: CS Student at Florida International University
- GitHub: [Carlos Lahrssen](https://github.com/carloslahrssen)

#### Name: [Caio Calderari](https://github.com/caiocall)
- Place: Campinas, São Paulo, Brazil
- Bio: Designer
- GitHub: [Caio Calderari](https://github.com/caiocall)

#### Name: [Chashmeet Singh](https://github.com/chashmeetsingh)
- Place: New Delhi, India
- Bio: CS Student
- GitHub: [Chashmeet Singh](https://github.com/chashmeetsingh)

#### Name: [Aimee Tacchi](https://github.com/darkxangel84)
- Place: England, UK
- Bio: Female Front-End Developer From England, UK, I love Code, Cats and Tea. Also love travelling.
- GitHub: [darkxangel84](https://github.com/darkxangel84)

#### Name: [Stuart Wares](https://github.com/StuWares)
- Place: Tamworth, United Kingdom
- Bio: Learning web development to help with a career change!
- GitHub: [Stu Wares](https://github.com/StuWares)

#### Name: [Aitor Alonso](https://github.com/tairosonloa)
- Place: Madrid, Spain
- Bio: Computer Science and Engineering BSc student at Carlos III University of Madrid
- GitHub: [Aitor Alonso](https://github.com/tairosonloa)

#### Name: [Veronika Tolpeeva](https://github.com/ostyq)
- Place: Moscow, Russia
- Bio: Web developer
- GitHub: [Veronika Tolpeeva](https://github.com/ostyq)

#### Name: [Dzmitry Kasinets](https://github.com/dkasinets)
- Place: Brooklyn, NY, USA
- Bio: CS student at Brooklyn College, and The Game of Thrones fan :3
- Github: [Dzmitry Kasinets](https://github.com/dkasinets)

#### Name: [Anthony Mineo](https://github.com/amineo)
- Place: New Jersey, USA
- Bio: Web Design & Development
- GitHub: [Anthony Mineo](https://github.com/amineo)

#### Name: [Brent Scheppmann](https://github.com/bareon)
- Place: Garden Grove, CA, US
- Bio: Student, Geophysicist
- GitHub: [Brent Scheppmann](https://github.com/bareon)

#### Name: [Andrea Stringham](https://github.com/astringham)
- Place: Phoenix, AZ USA
- Bio: Coffee addict, dog person, developer.
- GitHub: [Andrea Stringham](https://github.com/astringham)

#### Name: [coastalchief](https://github.com/coastalchief)
- Place: Germany
- Bio: dev
- GitHub: [coastalchief](https://github.com/coastalchief)

#### Name: [Furkan Arabaci](https://github.com/illegaldisease)
- Place: Turkey
- Bio: Computer Science student
- GitHub: [Furkan Arabaci](https://github.com/illegaldisease)

#### Name: [Rizki Ramadhana](https://github.com/rizkiprof)
- Place: Yogyakarta, Indonesia
- Bio: Student / Front-end Developer
- GitHub: [Rizki Ramadhana](https://github.com/rizkiprof)

#### Name: [Sarthak Bhagat](https://github.com/sarthak268)
- Place: Delhi, India
- Bio: ECE Undergraduate
- GitHub: [Sarthak Bhagat](https://github.com/sarthak268)

#### Name: [Haley C Smith](https://github.com/haleycs)
- Place: Orlando, Florida
- Bio: Web Designer/Developer
- GitHub: [Haley C Smith](https://github.com/haleycs)

#### Name: [Lesyntheti](https://github.com/lesyntheti)
- Place : Troyes, France
- Bio : Network Engineer at University of Technology of Troyes
- Github: [lesyntheti](https://gitbub.com/lesyntheti)

#### Name: [Abdullateef](https://github.com/abdullateef97)
- Place: Lagos Island, Lagos State, Nigeria
- Bio: Student Developer
- GitHub: [Abdullateef](https://github.com/abdullateef97)

#### Name: [Juan Anaya Ortiz](https://github.com/JaoChaos)
- Place: Granada, Spain
- Bio: IT student at the University of Granada
- GitHub: [Juan Anaya Ortiz](https://github.com/JaoChaos)

#### Name: [Alexander Voigt](https://github.com/alexandvoigt)
- Place: San Francisco, CA, USA
- Bio: Software Engineer
- GitHub: [Alexander Voigt](https://github.com/alexandvoigt)

#### Name: [Michael Greene] (https://github.com/Greeneink4)
- Place: UT, USA
- Bio: Web Dev Student
- Github: [Michael Greene] (https://github.com/Greeneink4)

#### Name: [Lee Magbanua](https://github.com/leesenpai)
- Place: Philippines
- Bio: Student / Front-end Web Developer
- GitHub: [leesenpai](https://github.com/leesenpai)

#### Name: [Damodar Lohani](https://github.com/lohanidamodar)
- Place: Kathmandu, Nepal
- Bio: Technology Consultant at [LohaniTech](https://lohanitech.com)
- GitHub: [Damodar Lohani](https://github.com/lohanidamodar)

#### Name: [Hrafnkell Orri Sigurðsson](https://github.com/hrafnkellos)
- Place: Hafnarfjörður, Iceland
- Bio: Computer Scientist
- GitHub: [Hrafnkell Orri Sigurðsson](https://github.com/hrafnkellos)

#### Name: [Mitchell Haugen](https://github.com/haugenmitch)
- Place: VA, USA
- Bio: Programmer
- GitHub: [haugenmitch](https://github.com/haugenmitch)

#### Name: [Felipe Do Espirito Santo](https://github.com/felipez3r0)
- Place: Jaboticabal, SP, Brazil
- Bio: Professor at Fatec, Faculdade São Luís, and Mozilla Volunteer
- GitHub: [Felipe Do E. Santo](https://github.com/felipez3r0)

#### Name: [Jason Green](https://jason.green)
- Place: Seattle, WA
- Bio: Student of code, eater of sustainable sushi
- GitHub: [Jalence](https://github.com/jalence)

#### Name: [Elan Ripley](https//github.com/tattarrattat)
- Place: Raleigh, North Carolina, USA
- Bio: Programmer
- Github: [Elan Ripley](https//github.com/tattarrattat)

#### Name: [Justin Oliver](https://github.com/justinoliver)
- Place: Seattle, WA, USA, Earth!
- Bio: Trying to learn cool new things!
- GitHub: [Justin Oliver](https://github.com/justinoliver)

#### Name: [RYAN R SMITH](https://github.com/devronsoft)
- Place: Oxford, UK
- Bio: Kiwi dev
- GitHub: [Ryan Smith](https://github.com/devronsoft)
- Website: [Blog](https://devronsoft.github.io/)

#### Name: [Michael Kaiser](https://github.com/patheticpat)
- Place: Germany
- Bio: Ooooooh, nooooooo, not tonight!!
- GitHub: [Michael Kaiser](https://github.com/patheticpat)

#### Name: [Igor Rzegocki](https://github.com/ajgon)
- Place: Kraków, PL
- Bio: I do Ruby for living, and hacking for fun
- GitHub: [Igor Rzegocki](https://github.com/ajgon)
- Website: [Online Portfolio](https://rzegocki.pl/)

#### Name: [JULIE QIU](https://github.com/julieqiu)
- Place: New York City, NY, USA
- Bio: Software Engineer; Loves iced coffee
- GitHub: [Julie Qiu](https://github.com/julieqiu)

#### Name: [Luis Alducin](https://linkedin.com/luisalduucin)
- Place: Mexico City
- Bio: Software Engineer
- GitHub: [Luis Alducin](https://github.com/luisalduucin)

#### Name: [Hannah Zulueta](https://github.com/hanapotski)
- Place: North Hollywood, CA
- Bio: Web developer, Calligrapher, Musician, Entrepreneur
- GitHub: [Ryan Smith](https://github.com/hanapotski)
- Website: [Blog](https://homemadecoder.wordpress.com)

#### Name: [Michele Adduci](https://micheleadduci.net)
- Place: Germany
- Bio: Full Stack Developer, living on a CI/CD pipeline
- GitHub: [madduci](https://github.com/madduci)

#### Name: [Austin Carey](https://github.com/apcatx)
- Place: Austin, TX, USA
- Bio: Jr Full Stack Developer making my first contribution.
- GitHub: [apcatx](https://github.com/apcatx)

#### Name: [John Rexter Flores](https://github.com/alldeads)
- Place: Cebu, Philippines
- Bio: Full Stack Developer
- Github: [John Rexter Flores](https://github.com/alldeads)

#### Name: [Luciano Santana dos Santos](https://github.com/lucianosds)
- Place: Ponta Grossa, PR, Brasil
- Bio: Computer Network Professional
- Github: [Luciano Santana dos Santos](https://github.com/lucianosds)

#### Name: [Alex Choi](https://github.com/running-cool)
- Place: Athens, GA
- Bio: Student
- Github: [running-cool](https://github.com/running-cool)

#### Name: [Kshitiz Khanal](https://github.com/kshitizkhanal7)
- Place: Kathmandu, Nepal
- Bio: Open Data and Open Knowledge activist
- GitHub: [Kshitiz Khanal](https://github.com/kshitizkhanal7)

#### Name: [Manas kashyap](https://github.com/Manas-kashyap)
- Place: New Delhi, India
- Bio: Computer Science Engineering student at Amity University 
Noida
-Github: [Manas kashyap](https://github.com/Manas-kashyap)

#### Name: [Daksh Chaturvedi](https://github.com/daksh249)
- Place: New Delhi, India
- Bio: ECE Undergraduate at IIIT-Delhi
- GitHub: [Daksh Chaturvedi](https://github.com/daksh249)

#### Name: [SHANAKA ANURADHA](https://github.com/shanaka95)
- Place: Sri Lanka
- Bio: Undergraduate
- GitHub: [Shanaka95](https://github.com/shanaka95)

### Name: [Brandon Fadairo](https://github.com/BFadairo)
- Place: Columbus, Ohio
- Bio: A guy looking to change career fields
- GitHub: [Brandon Fadairo](https://github.com/BFadairo)

#### Name: [Lukas A](https://github.com/lukbukkit)
- Place: Kassel, Hesse, Germany
- Bio: Student on his way to the Abitur
- GitHub: [LukBukkit](https://github.com/lukbukkit)

#### Name: [Valera Kushnir](https://github.com/kashura)
- Place: Tampa, FL, USA
- Bio: Scrum Master and passionate technologist.
- GitHub: [kashura](https://github.com/kashura)

#### Name: [Eric Briese](https://github.com/Atrolantra)
- Place: Brisbane, Australia
- Bio: Student studying LAw and IT. Currently working as a software engineer.
- GitHub: [Atrolantra](https://github.com/Atrolantra)

#### Name: [Ayushverma8](https://github.com/Ayushverma8)
- Place: Indore, TN, IN
- Bio: I'm living the best part of my life and the life that I always wanted to. Surrounded by amazing people everyday. Rich in happiness, meager in hate. Seduce me with bikes and roads, invite me to trekking and long drives. I love food and sleep. I'm driven by music and art.
- GitHub: [Ayush](https://github.com/Ayushverma8)

#### Name: [VEBER Arnaud](https://github.com/VEBERArnaud)
- Place: Paris, France
- Bio: Solution Architect @ Eleven-Labs
- GitHub: [VEBERArnaud](https://github.com/VEBERArnaud)

#### Name: [Dushyant Rathore](https://github.com/dushyantRathore)
- Place: New Delhi, India
- Bio: Student
- GitHub: [dushyantRathore](https://github.com/dushyantRathore)

#### Name: [Attila Blascsak](https://github.com/blascsi)
- Place: Hungary
- Bio: Front-end dev. Love React!
- GitHub: [Attila Blascsak](https://github.com/blascsi)

#### Name: [Acquila Santos Rocha](https://github.com/DJAcquila)
- Place: Goiânia, Brasil
- Bio: Computer Science Student
- GitHub: [Acquila Santos Rocha](https://github.com/DJAcquila)

  ####  Name: [ cagrikarsli ] (https://github.com/cagrikarsli) Place:Türkiye ,Ankara Bio:Computer Engineer ,Turk :) [ cagrikarsli ] (https://github.com/cagrikarsli)