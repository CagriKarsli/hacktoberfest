<?php
// LANGUAGE: PHP 
// AUTHOR: Akharadet Piansupap
// GITHUB: https://github.com/mack-akp
$text = "Hello World!";
echo $text;
?>