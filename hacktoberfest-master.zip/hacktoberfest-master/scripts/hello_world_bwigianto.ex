defmodule HelloWorld do
  def hello do
    IO.puts "Hello World!"
  end
end
