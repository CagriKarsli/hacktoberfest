// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Jakub Bačo
// GITHUB: https://github.com/vysocina

let hello_world = 'Hello World!';
console.log(hello_world);
