// Language: Kotlin
// Environment: JVM
// Author: Nefari0uss
// Github: https://www.github.com/nefari0uss

package hello

fun(args : Array<String>) {
    println("Hello World!")
}
