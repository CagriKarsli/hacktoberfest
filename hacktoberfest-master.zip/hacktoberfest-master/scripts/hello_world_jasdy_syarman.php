<?php
// LANGUAGE: PHP
// ENV : PHP
// AUTHOR: Jasdy Syarman
// GITHUB: https://github.com/akutaktau/
// DOCS : php.net 
echo "Hello, world";
?>
