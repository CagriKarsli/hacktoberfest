# Hello World in R
cat("Hello world\n")
