# LANGUAGE: python
# AUTHOR: Siddhant Verma
# GITHUB: https://github.com/siddver007

import time

message = 'Hola World! Amigos.'
for ch in message:
	print ch,
	time.sleep(0.5)
