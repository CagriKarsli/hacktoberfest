# Language: Python
# Github: http://github.com/wh1zzer/

print('Hello, world!')
