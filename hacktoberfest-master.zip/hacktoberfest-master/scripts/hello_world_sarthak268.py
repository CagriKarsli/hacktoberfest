// LANGUAGE: Python
// AUTHOR: Sarthak Bhagat
// GITHUB: https://github.com/sarthak268

print "Hello World"
