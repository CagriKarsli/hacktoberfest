object HelloWorld {
   /*  
   * This will print 'Hello World' as the output
   */
      def main(args: Array[String]) {
      println("Hello, world!") // prints Hello World
   }
}