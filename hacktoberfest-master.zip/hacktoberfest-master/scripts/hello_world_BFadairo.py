# LANGUAGE: Python
# AUTHOR: Brandon Fadairo
# GITHUB: https://github.com/BFadairo

def helloWorld():
    print ('Hello World')


helloWorld()