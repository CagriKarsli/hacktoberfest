// LANGUAGE: Kotlin
// AUTHOR: Yashit Maheshwary
// GITHUB: https://github.com/YashitM

fun main(args: Array<String>) {
	println("Hello, World!")
}