// appreciate this opportunity, this is my 2nd PR! <3

console.log(`Hello hacktober`);