// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Stuart Wares, https://twitter.com/TameRocket
// GITHUB: https://github.com/StuWares

console.log("Hello, world!");