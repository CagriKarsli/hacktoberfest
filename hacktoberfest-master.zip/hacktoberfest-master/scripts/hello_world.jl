# LANGUAGE: Julia
# AUTHOR: Akram Rameez
# GITHUB: https://github.com/akram-rameez

println("Hello World!")