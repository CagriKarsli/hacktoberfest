# LANGUAGE: Elixir
# AUTHOR: Jose David
# this is my first line in Elixir :)

IO.puts "Hello world from Elixir :)"
