// LANGUAGE: Dart
// ENV: DartVM
// AUTHOR: Nguyen Do
// GITHUB: https://github.com/nguyendhse
void main() {
  print("Hello, World!");
}
