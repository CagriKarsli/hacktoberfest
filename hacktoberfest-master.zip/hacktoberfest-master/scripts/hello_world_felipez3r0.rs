// This is the main function
// Language: Rust
fn main() {
    // Print text to the console
    println!("Hello World!");
}
