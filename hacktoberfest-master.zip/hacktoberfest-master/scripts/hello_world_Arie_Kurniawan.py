# LANGUAGE: Python
# ENV: Python
# AUTHOR: Arie Kurniawan
# GITHUB: https://github.com/arkwrn

print ("Hello World!")
