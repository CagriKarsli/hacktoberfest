# Language: Elixir
# Author: Joseph Banks
# GitHub: https://github.com/JoeBanks13
IO.puts "Hello, world!"
