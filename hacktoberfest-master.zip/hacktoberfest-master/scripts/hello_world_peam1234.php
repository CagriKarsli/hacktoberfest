<?php
// LANGUAGE: PHP
// ENV : Nginx
// AUTHOR: Napat Rattanawaraha
// GITHUB: https://github.com/peam1234
echo "Hello, World!";
?>
