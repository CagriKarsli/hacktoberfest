/* LANGUAGE: C
 * AUTHOR: Josh Gadeken
 * GITHUB: https://github.com/process1183
 */

#include <stdio.h>

int main()
{
    printf("Hello, world!\n");
    return 0;
}
