// JS
// AUTHOR HALEY SMITH
// https://github.com/haleycs

console.log('Hello, World!');
