// LANGUAGE: C++
// AUTHOR: Rajeev
// GITHUB: https://github.com/rajeeviiit

#include <iostream>
using namespace std;

int main() 
{
    cout << "Hello, World!";
    return 0;
}