// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Susan Brooks
// GITHUB: https://github.com/getjnxed

var helloWorld = "Hello, world!"
console.log(helloWorld)
