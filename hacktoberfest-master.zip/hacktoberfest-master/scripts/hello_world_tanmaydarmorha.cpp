#include<iostream>
using namespace std;
int main()
{
  cout<<"Hello World"<<endl;
  cout<<"First contribution on Github";
  return 0;
}
