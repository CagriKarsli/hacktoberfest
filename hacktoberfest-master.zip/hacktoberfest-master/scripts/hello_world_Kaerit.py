'''
LANGUAGE: Python 3.5
AUTHOR: Kaerit
GITHUB: https://github.com/Kaerit
'''

print("Hello World!!")
