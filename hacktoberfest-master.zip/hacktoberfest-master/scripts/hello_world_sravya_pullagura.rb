# LANGUAGE: Ruby
# AUTHOR: Sravya Pullagura
# GITHUB: https://github.com/sravya96
# If you wourld like to learn Ruby on Rails, here is a great link to get started: 
# 	https://www.railstutorial.org/book/beginning

puts "Hello, World!"
