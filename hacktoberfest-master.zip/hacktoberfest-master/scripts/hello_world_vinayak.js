// Language: Javascript
// Env: Thanks, me too
// Author: Vinayak Shrivastava
// Github: https://github.com/ItachiUchiha1998
console.log('Hello, World!');