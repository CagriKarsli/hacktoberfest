# LANGUAGE: Python
# AUTHOR:Sergey Gorky
# GITHUB: https://github.com/sergeygorky

print("Hello, World!")