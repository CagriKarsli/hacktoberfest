#include <stdio.h>


int main(){
    printf ("HELLO WORLD\n");
    return (0);
}
