// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Ginanjar S.B | Egin10
// GITHUB: https://github.com/egin10

console.log('Hello, World!');
