// LANGUAGE: C
// AUTHOR: Kyle Fauer
// GITHUB: https://github.com/Fauer4Effect

#include <stdio.h>

int main(int argc, char ** argv) {
  printf("Hello, world!\n");
  return 0;
}

