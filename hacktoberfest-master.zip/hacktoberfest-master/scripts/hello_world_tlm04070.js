// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Trevor Meadows
// GITHUB: https://github.com/tlm04070

console.log("Hello World!");
