// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Lesyntheti
// GITHUB: https://github.com/lesyntheti

console.log('Hello, Wonderful World!');
