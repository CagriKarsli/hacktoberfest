# LANGUAGE: Python
# VERSION: Python 3.5.2 

print("Hello, World")
