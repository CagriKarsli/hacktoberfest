// LANGUAGE: Kotlin
// ENV: Kotlin
// AUTHOR: ItsT-Mo
// GITHUB: https://github.com/ItsT-Mo

fun main(args: Array<String>) {
    println("Hello World")
}