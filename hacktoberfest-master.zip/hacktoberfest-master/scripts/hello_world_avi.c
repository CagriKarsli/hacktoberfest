// LANGUAGE: C
// AUTHOR: Avinash Jaiswal
// GITHUB: https://github.com/littlestar642

#include <stdio.h>

main()
{
    printf("Hello,World!\n");
}