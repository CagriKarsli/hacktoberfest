// LANGUAGE: JavaScript
// ENV:      Node.js
// AUTHOR:   Christopher Bradshaw
// GITHUB:   https://github.com/kitsune7

console.log('Hello, World!')
