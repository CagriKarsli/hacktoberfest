// LANGUAGE: Javascript
// ENV:
// AUTHOR: Sarah Chen
// GITHUB: https://github.com/AliceWonderland

alert("Hello World!");
