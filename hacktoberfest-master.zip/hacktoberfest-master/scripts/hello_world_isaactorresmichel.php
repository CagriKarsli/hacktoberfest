<?php 
/** 
* LANGUAGE: PHP
* ENV: PHP/Apache/Nginx
* AUTHOR: Isaac Torres Michel
* GITHUB: https://github.com/isaactorresmichel
*/
echo "Hello World!";