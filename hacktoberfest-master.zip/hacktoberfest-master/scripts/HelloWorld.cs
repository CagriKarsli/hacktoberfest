/** 
* LANGUAGE: C#
* AUTHOR: Niket Mishra
* GITHUB: https://github.com/niketmishra**/

using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, world!");
            Console.ReadLine();
        }
    }
}