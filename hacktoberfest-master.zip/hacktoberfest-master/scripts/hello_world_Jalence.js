
// LANGUAGE: javascript
// AUTHOR: Jason Green
// GITHUB: https://github.com/jalence

console.log('Hello World!');
