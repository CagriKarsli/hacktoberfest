// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Rafael O M Lima
// GITHUB: https://github.com/rafaelkalan

console.log("Hello World")