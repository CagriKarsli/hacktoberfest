// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Serhii Baraniuk
// GITHUB: https://github.com/kenitive/hacktoberfest

console.log('Hello, World!');
