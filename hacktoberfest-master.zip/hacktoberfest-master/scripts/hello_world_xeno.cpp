// Language: C++
// Author: xenocidewiki
// GitHub: https://github.com/xenocidewiki

#include <iostream>

int main() {
    std::cout << "Hello, World!";

    return 0;
}