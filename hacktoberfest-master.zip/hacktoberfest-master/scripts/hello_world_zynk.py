# LANGUAGE: Python
# AUTHOR: Mark Schultz
# GITHUB: https://github.com/zynk

print('Hello, World!')
