<?php
/**
* LANGUAGE: PHP
* AUTHOR: Nikolett Hegedüs
* GitHub: https://github.com/henikolett
*/ 

echo 'Hello world!';