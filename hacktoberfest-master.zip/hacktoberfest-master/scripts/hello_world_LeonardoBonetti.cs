﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HacktoberFest
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello HacktoberFest World ");
            Console.ReadKey();
        }
    }
}
