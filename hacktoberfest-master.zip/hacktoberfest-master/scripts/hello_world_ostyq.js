// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Veronika Tolpeeva
// GITHUB: https://github.com/ostyq

console.log('Hello, World and Hacktoberfest!');
