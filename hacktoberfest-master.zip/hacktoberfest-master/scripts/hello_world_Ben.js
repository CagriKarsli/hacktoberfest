// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Ben Greenberg
// GITHUB: https://github.com/benhayehudi 

let hello = "Hello World!"

console.log(hello);