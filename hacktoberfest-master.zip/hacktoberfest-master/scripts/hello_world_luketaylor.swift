// LANGUAGE: Swift
// AUTHOR: Luke Taylor
// GITHUB: https://github.com/lmcjt37
// LINK: https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/GuidedTour.html

print("Hello, world!")
