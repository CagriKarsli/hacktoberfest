// LANGUAGE: Javascript
// AUTHOR: Hassan Sani
// GITHUB: https://github.com/inidaname/

console.log('Hello, World!');
