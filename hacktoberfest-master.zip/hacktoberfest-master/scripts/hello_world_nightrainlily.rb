# Author: Amaya Lim

puts "hello world!"