// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Oluwadamilola Babalola
// GITHUB: https://github.com/thedammyking

console.log('Hello World');