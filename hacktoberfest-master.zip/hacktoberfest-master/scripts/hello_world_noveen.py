# LANGUAGE: Python
# AUTHOR: Noveen Sachdeva
# GITHUB: https://github.com/noveens

print "Hello, World!"
