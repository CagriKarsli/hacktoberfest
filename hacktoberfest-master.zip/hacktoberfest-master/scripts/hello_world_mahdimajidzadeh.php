<?php 
/** 
* LANGUAGE: PHP
* ENV: PHP/Apache/Nginx
* AUTHOR: Mahdi Majidzadeh
* GITHUB: https://github.com/mahdimajidzadeh
*/
echo "Hello World!";
?>
