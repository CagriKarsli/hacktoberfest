// LANGUAGE: C
// AUTHOR: Harshil Agrawal
// GITHUB: https://github.com/harshil1712

#include <stdio.h>

void main(){
	printf("Hello, World!");
	getch();
}