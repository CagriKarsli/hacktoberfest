<?php
// LANGUAGE: PHP
 
// AUTHOR: Nikita Seliverstov
 
// GITHUB: https://github.com/nikitaseliverstov/
 
echo "Hello, world";
?>