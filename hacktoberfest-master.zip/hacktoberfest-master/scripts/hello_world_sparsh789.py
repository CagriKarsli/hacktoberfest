#LANGUAGE: Python
#AUTHOR: Sparsh Garg
#GITHUB: https://github.com/sparsh789 

print "Hello, World!"
