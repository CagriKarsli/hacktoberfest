// LANGUAGE: Java
// ENV: JVM
// AUTHOR: Luis Alducin
// GITHUB: https://github.com/luisalduucin

public class Hello_World {

    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }

}