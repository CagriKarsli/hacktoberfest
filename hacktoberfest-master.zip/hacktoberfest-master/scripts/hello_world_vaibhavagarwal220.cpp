
// LANGUAGE: C++
// ENV: GCC
// AUTHOR: Vaibhav Agarwal
// GITHUB: https://github.com/vaibhavagarwal220

#include <iostream>
using namesapce std;

int main()
{
	cout<<"Hello World"<<endl;
}