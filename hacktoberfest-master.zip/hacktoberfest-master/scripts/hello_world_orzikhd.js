// Language: Javascript
// Env: Thanks, me too
// Author: Dennis Orzikh
// Github: https://github.com/orzikhd
console.log('Hello, World!');
