# LANGUAGE: Bash
# AUTHOR: Taylan Dogan
# GITHUB: https://github.com/kondanta

#!/bin/bash
echo "Hello World!"