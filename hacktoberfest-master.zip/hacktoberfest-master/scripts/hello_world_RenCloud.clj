//LANGUAGE: CLOJURE
(println "Hello World!")
