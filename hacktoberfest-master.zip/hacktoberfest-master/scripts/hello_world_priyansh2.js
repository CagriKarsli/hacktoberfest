// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Priyansh Agrawal
// GITHUB: https://github.com/priyansh2

console.log('Hello, World!');