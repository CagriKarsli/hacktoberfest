// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Klaudia K.
// GITHUB: https://github.com/KalpiKK

console.log('Hello, World!');