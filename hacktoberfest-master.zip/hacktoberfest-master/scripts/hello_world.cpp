// LANGUAGE: C++
// AUTHOR: George Fotopoulos
// GITHUB: https://github.com/xorz57

#include <iostream>

int main() {
	std::cout << "Hello, World!" << std::endl;
	return 0;
}
