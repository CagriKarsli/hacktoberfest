# LANGUAGE: Ruby
# AUTHOR: Hannah Zulueta
# GITHUB: https://github.com/hanapotski

puts "Hello, World!"
