// LANGUAGE: Python
// AUTHOR: Justin Oliver
// GITHUB: https://github.com/justinoliver

print('Hello, World!')
