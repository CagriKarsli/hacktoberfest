// LANGUAGE: C
// AUTHOR: Pranav Bhasin
// GITHUB: https://github.com/pranavbhasin96

#include<stdio.h>
int main()
{
    printf("Hello, World!\n");
}
