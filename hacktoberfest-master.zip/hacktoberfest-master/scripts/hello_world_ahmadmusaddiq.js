// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Ahmad Musaddiq Mohammad
// GITHUB: https://github.com/ahmadmusaddiq

console.log('Hello, World!');
