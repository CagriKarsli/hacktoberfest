// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Ruslan Posevkin
// GITHUB: https://github.com/rusposevkin

console.log('Hello, World!');
